Todas las imagenes usadas y vistas en la guia ilustrativa estan en la carpeta images, sientanse libres de usarlas.

si tienen problemas con linkear las imagenes, js y o css asegurense de extraer directamente la carpeta al directorio en lugar de extraerla a otra carpeta