// script llenado dinamico

import myCards from "./components/myCards.js";
import myNavB from "./components/myNavB.js";

// script accordion
myNavB.showNav()
myCards.showCards()