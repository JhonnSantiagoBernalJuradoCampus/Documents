import myNav from "./components/myNav.js";

//database
myNav.showNav()
